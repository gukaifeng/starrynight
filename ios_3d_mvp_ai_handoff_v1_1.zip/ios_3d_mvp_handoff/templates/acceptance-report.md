# 验收报告模板 · 双设备版 v1.1

所有运行结果初始为 NOT TESTED，不是通过证明。D01：iPhone 17 标准版；D02：11 英寸 iPad Pro（M4，2024）。

文档/源码版本：待填。构建标识：待填。环境记录：待填。

| 用例 | D01 结果 | D02 结果 | 分设备证据 / 日志 / 说明 |
|---|---|---|---|
| T01 | NOT TESTED | NOT TESTED | 待填 |
| T02 | NOT TESTED | NOT TESTED | 待填 |
| T03 | NOT TESTED | NOT TESTED | 待填 |
| T04 | NOT TESTED | NOT TESTED | 待填 |
| T05 | NOT TESTED | NOT TESTED | 待填 |
| T06 | NOT TESTED | NOT TESTED | 待填 |
| T07 | NOT TESTED | NOT TESTED | 待填 |
| T08 | NOT TESTED | NOT TESTED | 待填 |
| T09 | NOT TESTED | NOT TESTED | 待填 |
| T10 | NOT TESTED | NOT TESTED | 待填 |
| T11 | NOT TESTED | NOT TESTED | 待填 |
| T12 | NOT TESTED | NOT TESTED | 待填 |
| T13 | NOT TESTED | NOT TESTED | 待填 |
| T14 | NOT TESTED | NOT TESTED | 待填 |
| T15 | NOT TESTED | NOT TESTED | 待填 |
| T16 | NOT TESTED | NOT TESTED | 待填 |
| T17 | NOT TESTED | NOT TESTED | 待填 |
| T18 | NOT TESTED | NOT TESTED | 待填 |
| T19 | NOT TESTED | NOT TESTED | 待填 |
| T20 | NOT TESTED | NOT TESTED | 待填 |
| T21 | NOT TESTED | NOT TESTED | 待填 |
| T22 | NOT TESTED | NOT TESTED | 待填 |
| T23 | NOT TESTED | NOT TESTED | 待填 |

T14–T16 等构建项可共用同一证据，注明引用；运行与性能用例不得互相替代。T18 对两台均适用；无执行环境写 NOT TESTED，不能按“没有高刷硬件”写 N/A。T18 的 PASS 仅表示诊断执行并留证，持续 120 是否达标必须在下表另写。

## 分设备性能记录

| 指标 | D01 | D02 |
|---|---|---|
| 实际系统 / 应用构建 | 待填 | 待填 |
| 实际渲染宽高 / 比例 / 画质 | 待填 | 待填 |
| 采样区间 / 环境温度 | 待填 | 待填 |
| 充电 / 录屏 / 调试器 | 待填 | 待填 |
| 低电量 / 帧率限制 / 热状态 | 待填 | 待填 |
| 60 目标下平均 / P95 / P99 帧耗时 | 待填 | 待填 |
| 60 档基线结论 | NOT TESTED | NOT TESTED |
| 120 目标下平均 / P95 / P99 帧耗时 | 待填 | 待填 |
| 持续 120 的证据、达标/未达标结论 | 未测，不推断通过 | 未测，不推断通过 |
| 20 次页面循环 | NOT TESTED | NOT TESTED |
| 10 分钟运行与内存趋势 | NOT TESTED | NOT TESTED |
| 最终呈现证据 / Unity 循环 FPS 区别 | 待填 | 待填 |

## 交接

干净重建：NOT TESTED。签名到期后重装：D01 / D02 均 NOT TESTED。不得把未等到实际到期写为到期重装通过。

## 总结

D01：已实现 / 已验证 / 未验证 / 已知限制，分别填写。

D02：已实现 / 已验证 / 未验证 / 已知限制，分别填写。

整体：缺少任一设备的必需验证时，只能“部分完成”，不能宣称双设备适配完成。范围外设备不构成阻塞，也不宣称支持。
