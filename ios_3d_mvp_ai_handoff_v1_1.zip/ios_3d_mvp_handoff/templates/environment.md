# 环境记录 · 双设备版 v1.1

状态：NOT TESTED。设备型号来自用户确认；系统、容量、工具版本与运行结果必须实际填写。

## 开发环境

| 项目 | 实际值 |
|---|---|
| Mac 型号 / 芯片 / 内存 | 待填，不推断已拥有某款 Mac |
| macOS 完整版本 | 待填 |
| Xcode 版本 / build number / SDK | 待填；须支持两台实际系统 |
| Unity 完整补丁号 / 发行版 | 待填 |
| URP / glTFast 精确版本 | 待填 |
| Swift language mode | 待填 |
| Deployment Target | 待验证；配置起点 17.0，不代表实测系统 |
| 宿主设备族 | 待验证：iPhone + iPad（1,2） |
| Unity iOS Target Device | 待验证：iPhone + iPad |
| Personal Team / 稳定 Bundle ID | 本地填写，不含账号秘密 |
| 源码 commit / 构建号 | 待填 |
| 模型 SHA-256 | 下载后填写 |

## 两台实际测试设备

| 项目 | D01 | D02 |
|---|---|---|
| 正式机型 | iPhone 17 标准版 | 11 英寸 iPad Pro（M4，2024） |
| 持有情况 | 用户已确认拥有 | 用户已确认拥有 |
| 实际系统与 build number | 待填 iOS | 待填 iPadOS |
| 容量 / 可确认的内存信息 | 待填或未知 | 待填；不默认 16GB |
| 屏幕最高刷新能力 | 120Hz（规格） | 120Hz（规格） |
| 测试显示状态 | 全屏竖屏；实际状态待填 | 全屏竖屏；窗口设置待填 |
| 低电量模式 / 限制帧率设置 | 待填 | 待填 |
| 原生布局 / 兼容模式检查 | NOT TESTED | NOT TESTED；必须非 iPhone 放大模式 |
| 配对 / Developer Mode | NOT TESTED | NOT TESTED |
| 空白原生 App 免费签名 Run | NOT TESTED | NOT TESTED |
| 完整宿主 App Run | NOT TESTED | NOT TESTED |
| 60 档采样 | NOT TESTED | NOT TESTED |
| 120 档诊断 | NOT TESTED | NOT TESTED |

两台真机均须验证。个人 UDID、账号秘密、私钥和签名材料只留本地。工具链或系统更新后，记录变化并重测。
