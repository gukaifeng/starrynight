# iOS / iPadOS 3D V0 — 双设备技术方案交接包 v1.1

本包是技术方案与实施辅助材料，不是已完成的 App 项目。v1.1 取代此前 v1.0 的设备范围规定。

## 唯一目标设备

- D01：iPhone 17 标准版（不是 Pro / Pro Max / Air）。
- D02：11 英寸 iPad Pro（M4，2024 年款，小号），不是 10.9 英寸、13 英寸或其他代际。

用户已确认持有这两台设备。两台都必须适配并独立验收；无需购买其他测试机。实际系统版本、iPad 容量与 Mac 环境由实施者记录，不在这里虚构。

本版仍只做原生首页/关于页、一个内置 RobotExpressive 静态模型、Unity 全屏展示、原生覆盖按钮与可靠进出。两台全屏竖屏为基础验收，不扩展语音、AI、角色动作、触摸或多角色；不以 iPhone 兼容放大模式替代 iPad 适配。

## 阅读顺序

先读 `ios_3d_mvp_technical_spec.md`（文档版本 1.1）。审阅使用 `AI_REVIEW_PROMPT.md`，实施使用 `AI_IMPLEMENT_PROMPT.md`。Word 供人工阅读，Markdown 适合给 AI。详细修改见 `CHANGELOG.md`。

## 文件内容

`ios_3d_mvp_technical_spec.md` / `.docx` 为同一份修订方案；`reference/fetch_sample_asset.py` 为保持不变的模型下载及 GLB 基础校验脚本；`templates/` 提供双设备环境记录与分列验收模板。

## 获取示例模型

包内不含模型二进制。在实现者电脑联网执行：

```bash
python3 reference/fetch_sample_asset.py --output sample_asset
```

确认许可与校验记录后，复制到最终 Unity 工程的 `Assets/ThirdParty/RobotExpressive/`。脚本不是完整 glTF 合规验证器；模型导入、画面与真机性能必须实际验证。本次修订未执行网络下载端到端测试。

## 免费真机测试

继续使用 Apple Account + Xcode Personal Team，不购买付费开发者会员。两台分别完成配对和开发授权；账号操作由本人完成，不把密码或私钥交给 AI。签名期限及限制见主文档。

## 交付状态

没有可运行的 Xcode/Unity 源工程、签名安装包、模型二进制或真机通过证明。60 FPS 为 V0 基线；两台均需执行 120 档诊断，但硬件最高刷新率不等于 App 持续帧率。无实际执行的项目必须标记 NOT TESTED。
